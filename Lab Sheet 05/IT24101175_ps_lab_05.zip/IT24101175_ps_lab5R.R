setwd("C:\\Users\\User\\Desktop\\IT24101175_PS Lab_05")
Delivery_Times <- read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
head(Delivery_Times)


hist(Delivery_Times$Delivery_Time,
  breaks = seq (20,70,length.out =10),
  right = FALSE,
  main = "Histogram of Delivery Times",
  xlab = "Delivery Time",
  ylab = "Frequency")


hist_data <- hist (Delivery_Times$Delivery_Time_.minutes.,
                   breaks = breaks,
                   plot = FALSE)
cum_freq <- cumsum(hist_data$counts)

plot (hist_data$breaks[-1],cum_freq,
      type ="o",
      main ="Cumulative Frequency Polygon (ogive)",
      xlab = "Delivery Times(minutes)",
      ylab = "Cumulative Frequency")

