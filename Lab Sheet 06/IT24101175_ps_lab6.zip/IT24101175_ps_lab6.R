setwd("C:\\Users\\User\\Desktop\\ps_lab6")
#Q1
#i.
#binomial distribution

#ii.
pbinom(46,50,0.85,lower.tail =FALSE)

#Q2
#i.
#number of customer calls per hour

#ii.
#poisson distribution

#iii.|
dpois(15,12)

